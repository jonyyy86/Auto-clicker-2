import SwiftUI

struct ContentView: View {
    @StateObject private var model = TapSessionModel()
    @State private var showingGuide = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.015, green: 0.055, blue: 0.03).ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 22) {
                        header
                        counterCard
                        intervalCard
                        controls
                        infoCard
                    }
                    .padding()
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showingGuide = true
                    } label: {
                        Image(systemName: "questionmark.circle")
                            .foregroundStyle(.green)
                    }
                    .accessibilityLabel("AssistiveTouch guide")
                }
            }
            .sheet(isPresented: $showingGuide) {
                AssistiveTouchGuide()
            }
            .onDisappear { model.stop() }
        }
        .tint(.green)
    }

    private var header: some View {
        VStack(spacing: 8) {
            Image(systemName: "hand.tap.fill")
                .font(.system(size: 42))
                .foregroundStyle(.green)
            Text("OSCA GREΔD")
                .font(.largeTitle.bold())
                .foregroundStyle(.white)
            Text("TAP COMPANION • VERSION 1.0")
                .font(.caption.weight(.semibold))
                .tracking(2)
                .foregroundStyle(.green.opacity(0.8))
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 18)
    }

    private var counterCard: some View {
        VStack(spacing: 8) {
            Text("SESSION COUNT")
                .font(.caption.weight(.bold))
                .tracking(1.5)
                .foregroundStyle(.green.opacity(0.85))
            Text("\(model.count)")
                .font(.system(size: 58, weight: .bold, design: .rounded))
                .monospacedDigit()
                .foregroundStyle(.white)
            Text(model.isRunning ? "SESSION RUNNING" : "READY")
                .font(.caption.bold())
                .foregroundStyle(model.isRunning ? .green : .secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(.green.opacity(0.35), lineWidth: 1))
    }

    private var intervalCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("TAP INTERVAL")
                    .font(.headline)
                    .foregroundStyle(.white)
                Spacer()
                Text(String(format: "%.1f sec", model.interval))
                    .font(.headline.monospacedDigit())
                    .foregroundStyle(.green)
            }
            Slider(value: $model.interval, in: 0.2...5.0, step: 0.1)
                .tint(.green)
                .disabled(model.isRunning)
            HStack {
                Text("Fast • 0.2s")
                Spacer()
                Text("Slow • 5.0s")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
    }

    private var controls: some View {
        VStack(spacing: 12) {
            Button {
                model.isRunning ? model.stop() : model.start()
            } label: {
                Label(model.isRunning ? "STOP SESSION" : "START SESSION",
                      systemImage: model.isRunning ? "stop.fill" : "play.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(model.isRunning ? Color.red.opacity(0.85) : Color.green)
                    .foregroundStyle(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            }
            Button {
                model.reset()
            } label: {
                Label("RESET COUNT", systemImage: "arrow.counterclockwise")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white.opacity(0.08))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            }
            .disabled(model.isRunning)
        }
    }

    private var infoCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("iOS compatibility", systemImage: "info.circle.fill")
                .font(.headline)
                .foregroundStyle(.green)
            Text("This app runs a timer and counts session ticks while it is open. It cannot send taps into Roblox or control another app. Use the help button for Apple's built-in accessibility options.")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.75))
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color.green.opacity(0.08), in: RoundedRectangle(cornerRadius: 18))
    }
}

@MainActor
final class TapSessionModel: ObservableObject {
    @Published var interval: Double = 1.0
    @Published private(set) var count: Int = 0
    @Published private(set) var isRunning = false
    private var timer: Timer?

    func start() {
        guard !isRunning else { return }
        isRunning = true
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.count += 1 }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        isRunning = false
    }

    func reset() {
        guard !isRunning else { return }
        count = 0
    }

    deinit {
        timer?.invalidate()
    }
}
