import SwiftUI

struct AssistiveTouchGuide: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Use Apple's built-in accessibility tools") {
                    Text("Open Settings → Accessibility → Touch → AssistiveTouch.")
                    Text("Turn on AssistiveTouch and explore the Custom Gestures option.")
                    Text("You can record a gesture and replay it when iOS allows. This is a user-initiated accessibility feature, not an unrestricted background auto-clicker.")
                }
                Section("Important") {
                    Text("AssistiveTouch behavior can vary by iOS version and app. It may not provide reliable repeated tapping in Roblox, and this app cannot operate it remotely.")
                    Text("Use automation only in ways permitted by the game and its rules.")
                }
            }
            .navigationTitle("AssistiveTouch Guide")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
