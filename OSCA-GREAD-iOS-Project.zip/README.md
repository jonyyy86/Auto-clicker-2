# OSCA GREΔD — iOS Tap Companion

SwiftUI iOS project. Bundle identifier: `com.oscagread.app`.

## What it does
- Configurable interval timer (0.2–5.0 seconds)
- Start/stop session controls
- Session tick counter and reset
- AssistiveTouch information guide

## Important iOS limitation
A normal third-party iOS app cannot inject touch events into Roblox or another app, draw a system-wide overlay, or remotely control another app. This project does not claim to do that. The timer/counter works while OSCA GREΔD is open.

For Apple's built-in accessibility options, open:
**Settings → Accessibility → Touch → AssistiveTouch**.

Custom gesture availability and behavior depend on iOS and the target app. It is user-initiated and is not guaranteed to act as a repeatable Roblox auto-clicker.

## Build
The GitHub Actions workflow creates an **unsigned IPA artifact**. Download it from the completed workflow run under Artifacts.

An unsigned IPA is not directly installable on a normal iPhone. It must be signed with a valid Apple development/distribution signing identity and provisioning profile before installation. The workflow intentionally does not include or request signing certificates.

## GitHub setup
1. Create a repository.
2. Upload the contents of this ZIP, preserving `.github/workflows/build.yml`.
3. Commit to `main` (or `master`).
4. Open the Actions tab and run **Build OSCA GREΔD iOS**.
5. Download `OSCA-GREAD-unsigned-IPA` from the completed run.
